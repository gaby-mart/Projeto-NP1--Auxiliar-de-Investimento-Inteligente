package com.example.telaprincipal;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

/*public class MainActivity extends AppCompatActivity {

    //Declaração variáveis
    EditText campoCapital, campoMeses, campoTaxa;
    Button botaoCalcular;

    TextView resultadoTexto;

    double capital;
    int tempoMeses;
    double taxaJuros;
    double montanteFinal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        //Ligação de XML com Java

        campoCapital = findViewById(R.id.capital);
        campoMeses = findViewById(R.id.tempoMeses);
        campoTaxa = findViewById(R.id.taxaJuros);
        resultadoTexto = findViewById(R.id.montanteFinal);
        botaoCalcular = findViewById(R.id.botaoCalcular);

        botaoCalcular.setOnClickListener(v -> { //Faz o botão funcionar quando clicado

            //Configurações de validação/segurança
            if (campoCapital.getText().toString().isEmpty()) {
                campoCapital.setError("Digite o Capital para prosseguir: ");
                return;
            }
            if (campoMeses.getText().toString().isEmpty()) {
                campoMeses.setError("Digite a quantidade de meses para prosseguir: ");
                return;
            }
            if (campoTaxa.getText().toString().isEmpty()) {
                campoTaxa.setError("Digite o valor da taxa de juros (em porcentagem) para prosseguir: ");
                return;
            }

            //If --> Significa Se em português, faz validações condicionais de acordo com o que está entre ()
            //getText().toString --> Pega o texto de dentro da variável de ligação e modifica o conteúdo para String
            //.setError --> demonstra a mensagem de erro diretamente no campo do EditText

            try { //Tenta executar

                //Pegando os valores e colocando um padrão de entrada

                capital = Double.parseDouble(campoCapital.getText().toString().replace(",", "."));
                tempoMeses = Integer.parseInt(campoMeses.getText().toString());
                taxaJuros = Double.parseDouble(campoTaxa.getText().toString().replace(",", "."));

                //Convertendo a taxa de juros para decimal
                taxaJuros = taxaJuros / 100; //Substitui o valor na taxa de juros pelo decimal

                //Calcula Juros Simples
                montanteFinal = capital * (1 + (taxaJuros * tempoMeses));

                //Mostrar Resultado
                resultadoTexto.setText("Montante Final: R$ " + String.format("%.2f", montanteFinal));

            } catch (Exception e) { //Evita que o app trave e--> variavel que guarda o
                //e.printStackTrace(); --> ative isso para ver o erro
                resultadoTexto.setText("Erro: verifique os dados digitados");
            }
        });*/

public class MainActivity extends AppCompatActivity {

    // ── DECLARAÇÃO DE VARIÁVEIS ───────────────────────────────────
    EditText campoCapital, campoMeses, campoPercentual;
    Button botaoCalcular;
    TextView resultadoTexto;

    double capital;
    int tempoMeses;
    // double taxaJuros; ← desativado, substituído pelo CDI fixo
    double percentualCDI;
    double montanteFinal;

    // ── CDI FIXO MENSAL (atualizar quando o Banco Central mudar) ──
    final double CDI_MENSAL = 0.8279 / 100; // 0.8279% ao mês — abril 2026

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // ── LIGAÇÃO XML COM JAVA ──────────────────────────────────
        campoCapital    = findViewById(R.id.capital);
        campoMeses      = findViewById(R.id.tempoMeses);
        campoPercentual = findViewById(R.id.percentualCDI);
        resultadoTexto  = findViewById(R.id.montanteFinal);
        botaoCalcular   = findViewById(R.id.botaoCalcular);
        // campoTaxa = findViewById(R.id.taxaJuros); ← desativado

        botaoCalcular.setOnClickListener(v -> {

            // ── VALIDAÇÃO DOS CAMPOS VAZIOS ───────────────────────
            if (campoCapital.getText().toString().isEmpty()) {
                campoCapital.setError("Digite o Capital para prosseguir:");
                return;
            }
            if (campoMeses.getText().toString().isEmpty()) {
                campoMeses.setError("Digite a quantidade de meses para prosseguir:");
                return;
            }
            // if (campoTaxa.getText().toString().isEmpty()) { ← desativado
            //     campoTaxa.setError("Digite a taxa de juros:");
            //     return;
            // }
            if (campoPercentual.getText().toString().isEmpty()) {
                campoPercentual.setError("Digite o percentual do CDI do seu banco (ex: 100, 110, 140):");
                return;
            }

            try {

                // ── LEITURA DOS CAMPOS ────────────────────────────
                capital       = Double.parseDouble(campoCapital.getText().toString().replace(",", "."));
                tempoMeses    = Integer.parseInt(campoMeses.getText().toString().trim());
                percentualCDI = Double.parseDouble(campoPercentual.getText().toString().replace(",", "."));

                // ── TAXA EFETIVA = CDI MENSAL × PERCENTUAL DO BANCO
                double fatorCDI    = percentualCDI / 100;
                double taxaEfetiva = CDI_MENSAL * fatorCDI;

                // ── FÓRMULA JUROS SIMPLES COM CDI ─────────────────
                montanteFinal      = capital * (1 + (taxaEfetiva * tempoMeses));
                double jurosGanhos = montanteFinal - capital;

                // ── EXIBIÇÃO DO RESULTADO ─────────────────────────
                resultadoTexto.setText(
                        "Montante Final: R$ " + String.format("%.2f", montanteFinal) + "\n" +
                                "Juros ganhos:   R$ " + String.format("%.2f", jurosGanhos)
                );

            } catch (Exception e) {
                // e.printStackTrace(); ← ative para ver o erro no Logcat
                resultadoTexto.setText("Erro: verifique os dados digitados");
            }
        });
    }
}
